package com.example.a2

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainScreen(
                onExplicitClick = {
                    val intent = Intent(this, SecondActivity::class.java)
                    startActivity(intent)
                },
                onImplicitClick = {
                    val intent = Intent("com.example.a2.SECOND_ACTIVITY")
                    startActivity(intent)
                }
            )
        }
    }
}

@Composable
fun MainScreen(
    onExplicitClick: () -> Unit,
    onImplicitClick: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "David K - 1403814",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Button(
            onClick = onExplicitClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Start Activity Explicitly")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onImplicitClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Start Activity Implicitly")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val intent = Intent(context, ImageActivity::class.java)
                context.startActivity(intent)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("View Image Activity")
        }
    }
}
