package com.example.assignment5

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val PERMISSION_REQUEST_CODE = 100
    private val CUSTOM_PERMISSION = "com.example.assignment5.MSE412"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 🔹 REQUEST PERMISSION IMMEDIATELY WHEN APP OPENS
        if (ContextCompat.checkSelfPermission(
                this,
                CUSTOM_PERMISSION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(CUSTOM_PERMISSION),
                PERMISSION_REQUEST_CODE
            )
        }

        setContent {
            MainScreen(
                onExplicitClick = {
                    val intent = Intent(this, SecondActivity::class.java)
                    startActivity(intent)
                },
                onImplicitClick = {
                    val intent = Intent("com.example.assignment5.SECOND_ACTIVITY")
                    startActivity(intent)
                }
            )
        }
    }
}

@Composable
fun MainScreen(
    onExplicitClick: () -> Unit,
    onImplicitClick: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "David K - 1403814",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Button(
            onClick = onExplicitClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Start Activity Explicitly")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onImplicitClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Start Activity Implicitly")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val intent = Intent(context, ImageActivity::class.java)
                context.startActivity(intent)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("View Image Activity")
        }
    }
}
