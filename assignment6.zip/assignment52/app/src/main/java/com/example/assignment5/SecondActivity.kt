package com.example.assignment5

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class SecondActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SecondScreen(
                onBackClick = {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                }
            )
        }
    }
}

@Composable
fun SecondScreen(onBackClick: () -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Mobile Software Engineering Challenges:")
        Spacer(modifier = Modifier.height(8.dp))
        Text("1. Battery usage")
        Text("2. Screen size variety")
        Text("3. Internet reliability")
        Text("4. App lifecycle handling")
        Text("5. Data security")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onBackClick) {
            Text("Main Activity")
        }
    }
}
