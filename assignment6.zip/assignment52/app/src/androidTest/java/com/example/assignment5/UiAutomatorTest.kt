package com.example.assignment5

import android.content.Intent
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.By
import androidx.test.uiautomator.UiDevice
import androidx.test.uiautomator.Until
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

private const val LAUNCH_TIMEOUT: Long = 5000
private const val PACKAGE_NAME = "com.example.assignment5"

@RunWith(AndroidJUnit4::class)
class UiAutomatorTest {

    private lateinit var device: UiDevice

    @Before
    fun setup() {
        // Initialize UiDevice instance
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())

        device.pressHome()

        val launcherPackage = device.launcherPackageName
        device.wait(Until.hasObject(By.pkg(launcherPackage).depth(0)), LAUNCH_TIMEOUT)

        val context = InstrumentationRegistry.getInstrumentation().context
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE_NAME)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        context.startActivity(intent)

        device.wait(Until.hasObject(By.pkg(PACKAGE_NAME).depth(0)), LAUNCH_TIMEOUT)
    }

    @Test
    fun testNavigateToSecondScreenAndVerifyChallenges() {
        val button = device.findObject(By.text("Start Activity Explicitly"))
        button?.click()

        device.wait(Until.hasObject(By.text("Mobile Software Engineering Challenges:")), 3000)

        assert(device.findObject(By.text("1. Battery usage")) != null)
        assert(device.findObject(By.text("2. Screen size variety")) != null)
        assert(device.findObject(By.text("3. Internet reliability")) != null)
        assert(device.findObject(By.text("4. App lifecycle handling")) != null)
        assert(device.findObject(By.text("5. Data security")) != null)


        assert(device.findObject(By.text("Main Activity")) != null)
    }


}
